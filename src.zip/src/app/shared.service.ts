import { HttpClient, HttpClientModule } from '@angular/common/http';


import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class SharedService {
  readonly APIUrl="http://localhost:44317/api";

  constructor(private http:HttpClient) { }
  getEmpList():Observable<any[]>{
  return this.http.get<any>(this.APIUrl+'/Employeetests')
  }
  getjobList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/tbl_Job')
    }
  addemployee(val:any){
    return this.http.post(this.APIUrl+'/tbl_Job',val)
  }
  create(val:any): Observable<any> {
    return this.http.post(this.APIUrl+'/tbl_Job', val);
  }
}



