import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { FormBuilder, Validators } from '@angular/forms';  
import { PrimeNGConfig } from 'primeng/api';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {
  EmployeeList: any=[] ;
  dataSaved = false;  
  employeeForm: any;  
   
  employeeIdUpdate = null;  
  massage = null;  
  constructor(private formbulider: FormBuilder,private service:SharedService,private primengConfig: PrimeNGConfig) { }
  
  ngOnInit(): void {
    this.getjobList();
    this.primengConfig.ripple = true;
    this.employeeForm = this.formbulider.group({  
      EmpName: ['', [Validators.required]],  
      DateOfBirth: ['', [Validators.required]],  
      EmailId: ['', [Validators.required]],  
      
    });  
  }
  getjobList(){
    this.service.getjobList().subscribe(data=>{
      this.EmployeeList=data ;
    });
}
}
