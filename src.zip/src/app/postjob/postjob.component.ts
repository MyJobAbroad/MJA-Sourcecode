import { Component, ElementRef, OnInit } from '@angular/core';
import { PrimeNGConfig, SelectItemGroup } from "primeng/api";
import {SelectItem} from 'primeng/api';
import { SharedService } from '../shared.service';
import {DynamicDialogRef} from 'primeng/dynamicdialog';
import { Router } from '@angular/router';




interface JobCat {
  name: string;
  code: string;
}
interface jobtype {
  name: string;
  code: string;
}
interface jobSalary {
  name: string;
  code: string;
}
interface City {
  name: string,
  code: string
}

@Component({
  selector: 'app-postjob',
  templateUrl: './postjob.component.html',
  styleUrls: ['./postjob.component.css']
})
export class PostjobComponent implements OnInit {


  
  value = ''; 
  JobCats: JobCat[];

  jobtype: jobtype[];

  jobSalary: SelectItemGroup[];

  cities: City[];

  selectedCityCodes?: string[];
  
  selectedCategory?: JobCat;

   
  selectedtype?: jobtype;
  selectedsalary?: string;
  city?: string;

  displayBasic?: boolean;

  
 
  categories: any[] = [{name: 'Accounting', key: 'A'}, {name: 'Marketing', key: 'M'}, {name: 'Production', key: 'P'}, {name: 'Research', key: 'R'}];
  text1: string = '<div>Hello World!</div><div>PrimeNG <b>Editor</b> Rocks</div><div><br></div>';
    
  text2?: string;
  text?: string;

  
  
  selectedValue?: string;
  ref: DynamicDialogRef = new DynamicDialogRef;

  Job = {
    JobTitle: '',
    JobRef: '',
    JobCat: '',
    JobType:'',
    Salary:'',
    SalaryBenefits:'',
    State:'',
    City:'',
    Pcode:'',
    SendApplication:'',
    JobDes:''

  };

  
  constructor(private primengConfig: PrimeNGConfig,private shared:SharedService,private router: Router) {

    this.JobCats = [
      {name: 'Select Please', code: 'SP'},
      {name: 'Permanent', code: 'NY'},
      {name: 'Part Time', code: 'RM'},
      {name: 'Full Time', code: 'LDN'},
      {name: 'Contract', code: 'IST'}
      
  ];
  this.jobtype = [
    {name: 'Select Please', code: 'SP'},
    {name: 'Accounting', code: 'NY'},
    {name: 'Finance', code: 'FI'},
    {name: 'Software', code: 'SW'}
    
    
];
this.cities = [
  
  {name: 'Uttar Pradesh', code: 'NY'},
  {name: 'Maharastra', code: 'RM'},
  {name: 'Kerala', code: 'LDN'},
  {name: 'Tamil Nadu', code: 'IST'},
  {name: 'Andra Pradesh', code: 'PRS'}
];
this.jobSalary = [
  
  {
    label: '10000-20000', value: '1', 
    items: [
        {label: '<15000', value: '11'},
        {label: '>15000', value: '12'},
       
    ]
},
{
    label: '20000-30000', value: '2', 
    items: [
      {label: '<25000', value: '21'},
      {label: '>25000', value: '22'},
    ]
},
{
  label: '30000-40000', value: '3', 
  items: [
    {label: '<35000', value: '31'},
    {label: '>35000', value: '32'},
  ]
}
  
];

   }

  ngOnInit(): void {
    
    this.primengConfig.ripple = true;
   
  }
  createJob(): void {
    const data = {
      JobTitle: this.Job.JobTitle,
      JobRef: this.Job.JobRef,
      JobCat:this.selectedCategory?.name,
      JobType:this.selectedtype?.name,
      Salary:this.selectedsalary,
      SalaryBenefits:this.Job.SalaryBenefits,
      State:this.Job.State,
      City:this.Job.City,
      Pcode:this.Job.Pcode,
      SendApplication:this.selectedValue,
      JobDes:this.text
    };
    
    this.shared.create(data)
    .subscribe(
      response => {
        console.log(response);
        
      },
      error => {
        console.log(error);
      });

      
}
showBasicDialog() {
  this.displayBasic = true;
}
action(){
 
  this.router.navigate([ 'crud' ])
}


}

  
 

