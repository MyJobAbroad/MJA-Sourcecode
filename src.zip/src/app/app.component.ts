import { Component } from '@angular/core';
import { PrimeNGConfig } from 'primeng/api';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  items: any[]= [];

    activeItem?: MenuItem ;
  title = 'angularapp';
  constructor(private config: PrimeNGConfig) {}

    ngOnInit() {
        this.config.setTranslation({
            accept: 'Accept',
            reject: 'Cancel',
            //translations
        });
        this.items = [
          
          {label: 'Job postings'},
          {label: 'Resume Search'},
          {label: 'Resume Alerts'},
          {label: 'Account'},
          {label: 'Logout'}
      ];

      this.activeItem = this.items[0];
    }
}
