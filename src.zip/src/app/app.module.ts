import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {  MatButtonModule} from '@angular/material/button';

import {  MatMenuModule} from '@angular/material/menu';
import {  MatDatepickerModule} from '@angular/material/datepicker';
import {  MatIconModule} from '@angular/material/icon';
import {  MatCardModule} from '@angular/material/card';
import {  MatSidenavModule} from '@angular/material/sidenav';
import {  MatFormFieldModule} from '@angular/material/form-field';
import {  MatInputModule} from '@angular/material/input';
import {  MatTooltipModule} from '@angular/material/tooltip';
import {  MatToolbarModule} from '@angular/material/toolbar';
 
import { HttpClientModule } from '@angular/common/http';
import { EmployeeComponent } from './employee/employee.component';
import { SharedService } from './shared.service';

import {ButtonModule} from 'primeng/button';

import { RippleModule } from 'primeng/ripple';

import {TableModule} from 'primeng/table';
import { PostjobComponent } from './postjob/postjob.component';
import {InputTextModule} from 'primeng/inputtext';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TabMenuModule } from 'primeng/tabmenu';
import {ListboxModule} from 'primeng/listbox';
import {DropdownModule} from 'primeng/dropdown';
import {RadioButtonModule} from 'primeng/radiobutton';
import {EditorModule} from 'primeng/editor';
import { TestingComponent } from './testing/testing.component';
import { MatRadioModule } from '@angular/material/radio'; 

import { MatNativeDateModule } from '@angular/material/core';
import { CrudComponent } from './crud/crud.component';

import {DialogModule} from 'primeng/dialog';

import { DividerModule } from "primeng/divider";

import {CardModule} from 'primeng/card';
import {FieldsetModule} from 'primeng/fieldset';
import {MultiSelectModule} from 'primeng/multiselect';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    PostjobComponent,
    TestingComponent,
    CrudComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
    ReactiveFormsModule,
    HttpClientModule,
    ButtonModule,
    RippleModule,
    TableModule,
    InputTextModule,
    BrowserAnimationsModule,
    TabMenuModule,
    ListboxModule,
    DropdownModule,
    RadioButtonModule,
    EditorModule,
    MatButtonModule,
    MatMenuModule,
    MatDatepickerModule,
    MatIconModule,
    MatCardModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatToolbarModule,
    MatRadioModule,
    MatNativeDateModule,
    DialogModule,
    DividerModule,
    CardModule,
    FieldsetModule,
    MultiSelectModule
      ],
  providers: [HttpClientModule,SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
