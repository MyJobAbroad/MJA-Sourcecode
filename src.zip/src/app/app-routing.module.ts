import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { PostjobComponent } from './postjob/postjob.component'
import { CrudComponent } from './crud/crud.component';

const routes: Routes = [
  {path:'employee',component:EmployeeComponent},
  {path:'postjob',component:PostjobComponent},
  {path:'crud',component:CrudComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
