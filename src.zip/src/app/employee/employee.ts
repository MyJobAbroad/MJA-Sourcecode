export class employee {
    EmployeeID?:string;
    Fullname?:string;
    Mobile?:string;
    
}