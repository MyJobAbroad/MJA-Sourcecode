import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { employee } from './employee';
import { PrimeNGConfig } from 'primeng/api';
import { FormBuilder, Validators } from '@angular/forms';  

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styles: [`
        :host ::ng-deep button {
            margin-right: .5em;
        }
    `]
})
export class EmployeeComponent implements OnInit {
  EmployeeList: any=[] ;
  dataSaved = false;  
  employeeForm: any;  
   
  employeeIdUpdate = null;  
  massage = null;  
  constructor(private formbulider: FormBuilder,private service:SharedService,private primengConfig: PrimeNGConfig) { }
  
  ngOnInit(): void {
    this.refreshemplist();
    this.primengConfig.ripple = true;
    this.employeeForm = this.formbulider.group({  
      EmpName: ['', [Validators.required]],  
      DateOfBirth: ['', [Validators.required]],  
      EmailId: ['', [Validators.required]],  
      
    });  
  }
refreshemplist(){
    this.service.getEmpList().subscribe(data=>{
      this.EmployeeList=data ;
    });

    
    
    
}

}
